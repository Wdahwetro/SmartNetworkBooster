package com.example.smartnetwork

import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.os.IBinder
import android.telephony.PhoneStateListener
import android.telephony.SignalStrength
import android.telephony.TelephonyManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var statusText: TextView
    lateinit var startButton: Button
    lateinit var stopButton: Button
    var vpnIntent: Intent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // إنشاء واجهة بسيطة
        val layout = LinearLayout(this)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(50, 50, 50, 50)

        statusText = TextView(this)
        statusText.text = "SmartNetworkBooster جاهز ✅"
        statusText.textSize = 20f
        layout.addView(statusText)

        startButton = Button(this)
        startButton.text = "بدء مراقبة الشبكة"
        layout.addView(startButton)

        stopButton = Button(this)
        stopButton.text = "إيقاف VPN"
        layout.addView(stopButton)

        setContentView(layout)

        // زر البدء
        startButton.setOnClickListener {
            statusText.text = "تم البدء في مراقبة الشبكة 🔄"
            vpnIntent = Intent(this, DNSVpnService::class.java)
            startService(vpnIntent)
            NetworkMonitor(this).startMonitoring()
        }

        // زر الإيقاف
        stopButton.setOnClickListener {
            vpnIntent?.let { stopService(it) }
            statusText.text = "تم إيقاف VPN ❌"
        }
    }
}

// خدمة VPN لتبديل DNS
class DNSVpnService : VpnService() {
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val builder = Builder()
        builder.addAddress("10.0.0.2", 32)
        builder.addDnsServer("1.1.1.1") // Cloudflare
        builder.addDnsServer("8.8.8.8") // Google
        builder.setSession("SmartDNS")
        builder.establish()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

// مراقبة قوة الشبكة
class NetworkMonitor(context: Context) {
    private val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

    fun startMonitoring() {
        val listener = object : PhoneStateListener() {
            override fun onSignalStrengthsChanged(signal: SignalStrength?) {
                super.onSignalStrengthsChanged(signal)
                signal?.let {
                    val level = it.level
                    if(level <= 1){
                        // إشارة ضعيفة → يمكن إضافة تحسين الشبكة هنا
                    }
                }
            }
        }
        tm.listen(listener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS)
    }
}